var canvas = document.getElementById("myCanvas");
// FIX: Cancel touch end event and handle click via touchstart
// canvas.addEventListener("touchend", function(e) { e.preventDefault(); }, false);
canvas.addEventListener("touchmove", doTouch, false);
canvas.addEventListener("click", doClick, false);
//canvas.addEventListener("mousemove", doClick, false);


var context = canvas.getContext('2d');
var centerX = canvas.width / 2;
var centerY = canvas.height / 2;
var innerRadius = canvas.width / 4.5;
var outerRadius = (canvas.width - 10) / 2;

//outer border
context.beginPath();
//outer circle
context.arc(centerX, centerY, outerRadius, 0, 2 * Math.PI, false);
//draw the outer border: (gets drawn around the circle!)
context.lineWidth = 4;
context.strokeStyle = '#000000';
context.stroke();
context.closePath();

//fill with beautiful colors 
//taken from here: http://stackoverflow.com/questions/18265804/building-a-color-wheel-in-html5
for (var angle = 0; angle <= 360; angle += 1) {
  var startAngle = (angle - 2) * Math.PI / 180;
  var endAngle = angle * Math.PI / 180;
  context.beginPath();
  context.moveTo(centerX, centerY);
  context.arc(centerX, centerY, outerRadius, startAngle, endAngle, false);
  context.closePath();
  context.fillStyle = 'hsl(' + angle + ', 100%, 50%)';
  context.fill();
  context.closePath();
}

//inner border
context.beginPath();
//context.arc(centerX, centerY, radius, startAngle, endAngle, counterClockwise);
context.arc(centerX, centerY, innerRadius, 0, 2 * Math.PI, false);
//fill the center
var my_gradient = context.createLinearGradient(0, 0, 170, 0);
my_gradient.addColorStop(0, "black");
my_gradient.addColorStop(1, "white");

context.fillStyle = my_gradient;
context.fillStyle = "white";
context.fill();

//draw the inner line
context.lineWidth = 2;
context.strokeStyle = '#000000';
context.stroke();
context.closePath();

//get Mouse x/y canvas position
function getMousePos(canvas, evt) {
  var rect = canvas.getBoundingClientRect();
  return {
    x: evt.clientX - rect.left,
    y: evt.clientY - rect.top };

}

//comp to Hex
function componentToHex(c) {
  //var hex = c.toString(16);
  //return hex.length == 1 ? "0" + hex : hex;
  return ("0" + Number(c).toString(16)).slice(-2).toUpperCase();
}

//rgb/rgba to Hex
function rgbToHex(rgb) {
  return componentToHex(rgb[0]) + componentToHex(rgb[1]) + componentToHex(rgb[2]);

}



//display the touch/click position and color info
function updateStatus(pos, color) {
  var hexColor = rgbToHex(color);
  wsSetAll(hexColor);

  hexColor = "#" + hexColor;

  $('#status').css("backgroundColor", hexColor);
  $('#status_color').text(hexColor + " - R=" + color[0] + ", G=" + color[1] + ", B=" + color[2]);
  console.log(hexColor + " - R=" + color[0] + ", G=" + color[1] + ", B=" + color[2]);
  $('#status_pos').text("x: " + pos.x + " - y: " + pos.y);

  $("#rng_red").val(color[0]);
  $("#rng_green").val(color[1]);
  $("#rng_blue").val(color[2]);


}

//handle the touch event
function doTouch(event) {
  //to not also fire on click
  event.preventDefault();
  var el = event.target;

  //touch position
  var pos = { x: Math.round(event.targetTouches[0].pageX - el.offsetLeft),
    y: Math.round(event.targetTouches[0].pageY - el.offsetTop) };
  //color
  var color = context.getImageData(pos.x, pos.y, 1, 1).data;

  updateStatus(pos, color);
}

function doClick(event) {
  //click position   
  var pos = getMousePos(canvas, event);
  //color
  var color = context.getImageData(pos.x, pos.y, 1, 1).data;

  //console.log("click", pos.x, pos.y, color);
  updateStatus(pos, color);

  //now do sth with the color rgbToHex(color);
  //don't do stuff when #000000 (outside circle and lines
}

function setMainColor() {
  var red = $("#rng_red").val();
  var green = $("#rng_green").val();
  var blue = $("#rng_blue").val();		
  
  var mainColorHex = componentToHex(red) + componentToHex(green) + componentToHex(blue);
  console.log(mainColorHex);
  wsSetMainColor(mainColorHex);
}

var rainbowEnable = false;
var connection = new WebSocket('ws://' + location.hostname + ':81/', ['arduino']);
connection.onopen = function () {
  connection.send('Connect ' + new Date());
};
connection.onerror = function (error) {
  console.log('WebSocket Error ', error);
};
connection.onmessage = function (e) {
  console.log('Server: ', e.data);
};
connection.onclose = function () {
  console.log('WebSocket connection closed');
};




function wsSetAll(hexColor) {

  var rgb = hexColor;
  var RGBhexColor = '*' + rgb.toString(17);
  console.log(RGBhexColor);
  connection.send(RGBhexColor);
}

var values = document.getElementById("values");

function sendRGB() {
  var r = document.getElementById('r').value ** 2 / 1023;
  var g = document.getElementById('g').value ** 2 / 1023;
  var b = document.getElementById('b').value ** 2 / 1023;

  var rgb = r << 20 | g << 10 | b;
  var rgbstr = '#' + rgb.toString(16);
  console.log('RGB: ' + rgbstr);

  connection.send(rgbstr);

}



function rainbowEffect() {
  rainbowEnable = !rainbowEnable;
  if (rainbowEnable) {
    connection.send("R");
    document.getElementById('rainbow').style.backgroundColor = '#00878F';
    document.getElementById('r').className = 'disabled';
    document.getElementById('g').className = 'disabled';
    document.getElementById('b').className = 'disabled';
    document.getElementById('r').disabled = true;
    document.getElementById('g').disabled = true;
    document.getElementById('b').disabled = true;
  } else {
    connection.send("N");
    document.getElementById('rainbow').style.backgroundColor = '#999';
    document.getElementById('r').className = 'enabled';
    document.getElementById('g').className = 'enabled';
    document.getElementById('b').className = 'enabled';
    document.getElementById('r').disabled = false;
    document.getElementById('g').disabled = false;
    document.getElementById('b').disabled = false;
    sendRGB();
  }
}